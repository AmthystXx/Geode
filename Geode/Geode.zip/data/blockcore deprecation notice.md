# The blockcore folder is DEPRECATED!

All changes to blockcore going forward will be handled in Geode. The blockcore folder is only here to offer compatability for packs that haven't updated to use the geode namespace.